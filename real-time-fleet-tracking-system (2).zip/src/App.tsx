import { useState, useCallback } from 'react';
import Sidebar from './components/Sidebar';
import Header from './components/Header';
import Dashboard from './components/Dashboard';
import LiveMap from './components/LiveMap';
import FleetView from './components/FleetView';
import ShipmentsView from './components/ShipmentsView';
import RoutesView from './components/RoutesView';
import AnalyticsView from './components/AnalyticsView';
import { TabType } from './data/types';

const headerConfig: Record<TabType, { title: string; subtitle: string }> = {
  dashboard: { title: 'Dashboard', subtitle: 'Overview of fleet operations and key metrics' },
  map: { title: 'Live Tracking Map', subtitle: 'Real-time vehicle positions and routes' },
  fleet: { title: 'Fleet Management', subtitle: 'Monitor and manage all vehicles' },
  shipments: { title: 'Shipments', subtitle: 'Track and manage all shipments' },
  routes: { title: 'Route Management', subtitle: 'Plan and optimize delivery routes' },
  analytics: { title: 'Performance Analytics', subtitle: 'Insights and reporting dashboard' },
};

export default function App() {
  const [activeTab, setActiveTab] = useState<TabType>('dashboard');
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [selectedVehicle, setSelectedVehicle] = useState<string | null>(null);

  const handleSelectVehicleOnMap = useCallback((id: string) => {
    setSelectedVehicle(id);
    setActiveTab('map');
  }, []);

  const renderContent = () => {
    switch (activeTab) {
      case 'dashboard':
        return <Dashboard />;
      case 'map':
        return (
          <LiveMap 
            selectedVehicle={selectedVehicle} 
            onSelectVehicle={setSelectedVehicle} 
          />
        );
      case 'fleet':
        return <FleetView onSelectVehicle={handleSelectVehicleOnMap} />;
      case 'shipments':
        return <ShipmentsView />;
      case 'routes':
        return <RoutesView />;
      case 'analytics':
        return <AnalyticsView />;
      default:
        return <Dashboard />;
    }
  };

  return (
    <div className="flex h-screen w-screen bg-slate-950 overflow-hidden">
      <Sidebar
        activeTab={activeTab}
        onTabChange={setActiveTab}
        collapsed={sidebarCollapsed}
        onToggle={() => setSidebarCollapsed(!sidebarCollapsed)}
        alertCount={3}
      />
      <div className="flex-1 flex flex-col min-w-0">
        <Header
          title={headerConfig[activeTab].title}
          subtitle={headerConfig[activeTab].subtitle}
        />
        <main className="flex-1 overflow-hidden">
          {renderContent()}
        </main>
      </div>
    </div>
  );
}
