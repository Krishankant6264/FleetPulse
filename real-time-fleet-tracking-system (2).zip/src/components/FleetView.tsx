import { useState } from 'react';
import { Truck, MapPin, Fuel, Gauge, Phone, Clock, ChevronRight, Search } from 'lucide-react';
import { vehicles } from '../data/mockData';

const statusConfig: Record<string, { bg: string; text: string; dot: string; label: string }> = {
  active: { bg: 'bg-emerald-500/10', text: 'text-emerald-400', dot: 'bg-emerald-500', label: 'Active' },
  idle: { bg: 'bg-amber-500/10', text: 'text-amber-400', dot: 'bg-amber-500', label: 'Idle' },
  maintenance: { bg: 'bg-blue-500/10', text: 'text-blue-400', dot: 'bg-blue-500', label: 'Maintenance' },
  offline: { bg: 'bg-slate-500/10', text: 'text-slate-400', dot: 'bg-slate-500', label: 'Offline' },
};

const typeEmoji: Record<string, string> = {
  truck: '🚛',
  van: '🚐',
  bike: '🏍️',
};

interface FleetViewProps {
  onSelectVehicle?: (id: string) => void;
}

export default function FleetView({ onSelectVehicle }: FleetViewProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [selectedId, setSelectedId] = useState<string | null>(null);

  const filtered = vehicles.filter(v => {
    const matchSearch = v.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
                       v.driver.toLowerCase().includes(searchTerm.toLowerCase());
    const matchStatus = statusFilter === 'all' || v.status === statusFilter;
    return matchSearch && matchStatus;
  });

  const selectedVehicle = selectedId ? vehicles.find(v => v.id === selectedId) : null;

  return (
    <div className="flex h-full">
      {/* Vehicle List */}
      <div className={`${selectedVehicle ? 'w-1/2 lg:w-2/5' : 'w-full'} border-r border-slate-800 flex flex-col`}>
        {/* Filters */}
        <div className="p-4 border-b border-slate-800 space-y-3">
          <div className="relative">
            <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
            <input
              type="text"
              placeholder="Search vehicles or drivers..."
              value={searchTerm}
              onChange={e => setSearchTerm(e.target.value)}
              className="w-full bg-slate-800/60 border border-slate-700/50 rounded-xl pl-9 pr-4 py-2.5 text-sm text-slate-300 placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-blue-500/30"
            />
          </div>
          <div className="flex gap-2 overflow-x-auto pb-1">
            {['all', 'active', 'idle', 'maintenance', 'offline'].map(s => (
              <button
                key={s}
                onClick={() => setStatusFilter(s)}
                className={`px-3 py-1.5 rounded-lg text-xs font-medium capitalize whitespace-nowrap transition-all cursor-pointer
                  ${statusFilter === s 
                    ? 'bg-blue-600 text-white' 
                    : 'bg-slate-800 text-slate-400 hover:bg-slate-700'
                  }`}
              >
                {s} {s !== 'all' ? `(${vehicles.filter(v => v.status === s).length})` : `(${vehicles.length})`}
              </button>
            ))}
          </div>
        </div>

        {/* Vehicle Cards */}
        <div className="flex-1 overflow-y-auto p-4 space-y-3">
          {filtered.map(v => {
            const status = statusConfig[v.status];
            return (
              <div
                key={v.id}
                onClick={() => setSelectedId(v.id)}
                className={`p-4 rounded-2xl border cursor-pointer transition-all duration-200 ${
                  selectedId === v.id 
                    ? 'bg-blue-600/10 border-blue-500/30 shadow-lg shadow-blue-500/5' 
                    : 'bg-slate-900/60 border-slate-800 hover:border-slate-700 hover:bg-slate-800/40'
                }`}
              >
                <div className="flex items-start gap-3">
                  <div className="w-12 h-12 rounded-xl bg-slate-800 border border-slate-700 flex items-center justify-center text-2xl flex-shrink-0">
                    {typeEmoji[v.type]}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between">
                      <h3 className="text-sm font-semibold text-white truncate">{v.name}</h3>
                      <span className={`flex items-center gap-1.5 text-xs font-medium px-2 py-0.5 rounded-full ${status.bg} ${status.text}`}>
                        <span className={`w-1.5 h-1.5 rounded-full ${status.dot} ${v.status === 'active' ? 'animate-pulse' : ''}`}></span>
                        {status.label}
                      </span>
                    </div>
                    <p className="text-xs text-slate-500 mt-0.5">{v.driver}</p>
                    <div className="flex items-center gap-4 mt-2">
                      <span className="flex items-center gap-1 text-xs text-slate-400">
                        <Gauge size={12} />
                        {v.speed} mph
                      </span>
                      <span className="flex items-center gap-1 text-xs text-slate-400">
                        <Fuel size={12} />
                        {v.fuel}%
                      </span>
                      <span className="flex items-center gap-1 text-xs text-slate-400">
                        <Clock size={12} />
                        {v.lastUpdate}
                      </span>
                    </div>
                  </div>
                  <ChevronRight size={16} className="text-slate-600 flex-shrink-0 mt-2" />
                </div>
                
                {/* Progress bar for deliveries */}
                {v.deliveriesTotal > 0 && (
                  <div className="mt-3 pt-3 border-t border-slate-800">
                    <div className="flex items-center justify-between text-xs mb-1.5">
                      <span className="text-slate-500">Deliveries</span>
                      <span className="text-slate-300 font-medium">{v.deliveriesCompleted}/{v.deliveriesTotal}</span>
                    </div>
                    <div className="h-1.5 bg-slate-800 rounded-full overflow-hidden">
                      <div 
                        className="h-full bg-gradient-to-r from-blue-500 to-cyan-400 rounded-full transition-all"
                        style={{ width: `${(v.deliveriesCompleted / v.deliveriesTotal) * 100}%` }}
                      />
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>

      {/* Detail Panel */}
      {selectedVehicle && (
        <div className="flex-1 overflow-y-auto p-6">
          <div className="max-w-2xl mx-auto space-y-6">
            {/* Header */}
            <div className="flex items-center gap-4">
              <div className="w-16 h-16 rounded-2xl bg-slate-800 border border-slate-700 flex items-center justify-center text-4xl">
                {typeEmoji[selectedVehicle.type]}
              </div>
              <div>
                <h2 className="text-xl font-bold text-white">{selectedVehicle.name}</h2>
                <p className="text-sm text-slate-400">{selectedVehicle.driver}</p>
                <div className="flex items-center gap-2 mt-1">
                  <span className={`flex items-center gap-1.5 text-xs font-medium px-2 py-0.5 rounded-full ${statusConfig[selectedVehicle.status].bg} ${statusConfig[selectedVehicle.status].text}`}>
                    <span className={`w-1.5 h-1.5 rounded-full ${statusConfig[selectedVehicle.status].dot}`}></span>
                    {statusConfig[selectedVehicle.status].label}
                  </span>
                  <span className="text-xs text-slate-500">Last update: {selectedVehicle.lastUpdate}</span>
                </div>
              </div>
            </div>

            {/* Stats Grid */}
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
              {[
                { label: 'Speed', value: `${selectedVehicle.speed} mph`, icon: <Gauge size={16} /> },
                { label: 'Fuel Level', value: `${selectedVehicle.fuel}%`, icon: <Fuel size={16} /> },
                { label: 'Mileage', value: `${selectedVehicle.mileage.toLocaleString()} mi`, icon: <Truck size={16} /> },
                { label: 'ETA', value: selectedVehicle.eta || '—', icon: <Clock size={16} /> },
              ].map(stat => (
                <div key={stat.label} className="bg-slate-800/60 border border-slate-700/50 rounded-xl p-3">
                  <div className="flex items-center gap-2 mb-2 text-slate-500">
                    {stat.icon}
                    <span className="text-xs">{stat.label}</span>
                  </div>
                  <p className="text-lg font-bold text-white">{stat.value}</p>
                </div>
              ))}
            </div>

            {/* Fuel Gauge */}
            <div className="bg-slate-900/60 border border-slate-800 rounded-2xl p-5">
              <h3 className="text-sm font-semibold text-white mb-3">Fuel Level</h3>
              <div className="h-4 bg-slate-800 rounded-full overflow-hidden">
                <div 
                  className={`h-full rounded-full transition-all ${
                    selectedVehicle.fuel > 50 ? 'bg-gradient-to-r from-emerald-500 to-emerald-400' 
                    : selectedVehicle.fuel > 25 ? 'bg-gradient-to-r from-amber-500 to-amber-400' 
                    : 'bg-gradient-to-r from-red-500 to-red-400'
                  }`}
                  style={{ width: `${selectedVehicle.fuel}%` }}
                />
              </div>
              <div className="flex justify-between mt-2 text-xs text-slate-500">
                <span>Empty</span>
                <span>{selectedVehicle.fuel}%</span>
                <span>Full</span>
              </div>
            </div>

            {/* Delivery Progress */}
            {selectedVehicle.deliveriesTotal > 0 && (
              <div className="bg-slate-900/60 border border-slate-800 rounded-2xl p-5">
                <h3 className="text-sm font-semibold text-white mb-3">Delivery Progress</h3>
                <div className="flex items-center gap-4 mb-3">
                  <div className="text-3xl font-bold text-white">{selectedVehicle.deliveriesCompleted}</div>
                  <div className="text-slate-500">/</div>
                  <div className="text-xl text-slate-400">{selectedVehicle.deliveriesTotal}</div>
                  <div className="text-xs text-slate-500">deliveries completed</div>
                </div>
                <div className="h-3 bg-slate-800 rounded-full overflow-hidden">
                  <div 
                    className="h-full bg-gradient-to-r from-blue-500 to-cyan-400 rounded-full transition-all"
                    style={{ width: `${(selectedVehicle.deliveriesCompleted / selectedVehicle.deliveriesTotal) * 100}%` }}
                  />
                </div>
              </div>
            )}

            {/* Contact */}
            <div className="bg-slate-900/60 border border-slate-800 rounded-2xl p-5">
              <h3 className="text-sm font-semibold text-white mb-3">Driver Contact</h3>
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-slate-800 border border-slate-700 flex items-center justify-center text-sm font-bold text-white">
                  {selectedVehicle.driverAvatar}
                </div>
                <div className="flex-1">
                  <p className="text-sm font-medium text-white">{selectedVehicle.driver}</p>
                  <p className="text-xs text-slate-500">{selectedVehicle.phone}</p>
                </div>
                <button className="p-2.5 rounded-xl bg-blue-600/10 border border-blue-500/20 text-blue-400 hover:bg-blue-600/20 transition-all">
                  <Phone size={16} />
                </button>
                <button 
                  onClick={() => onSelectVehicle?.(selectedVehicle.id)}
                  className="p-2.5 rounded-xl bg-emerald-600/10 border border-emerald-500/20 text-emerald-400 hover:bg-emerald-600/20 transition-all"
                >
                  <MapPin size={16} />
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
