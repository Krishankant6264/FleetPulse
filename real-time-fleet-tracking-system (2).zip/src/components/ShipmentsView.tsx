import { useState } from 'react';
import { Package, Search, Clock, Weight, AlertTriangle, CheckCircle2, Truck, ChevronRight, ArrowRight, X } from 'lucide-react';
import { shipments, vehicles } from '../data/mockData';
import { Shipment } from '../data/types';

const statusConfig: Record<string, { bg: string; text: string; border: string; label: string }> = {
  pending: { bg: 'bg-slate-500/10', text: 'text-slate-400', border: 'border-slate-500/20', label: 'Pending' },
  picked_up: { bg: 'bg-blue-500/10', text: 'text-blue-400', border: 'border-blue-500/20', label: 'Picked Up' },
  in_transit: { bg: 'bg-cyan-500/10', text: 'text-cyan-400', border: 'border-cyan-500/20', label: 'In Transit' },
  out_for_delivery: { bg: 'bg-purple-500/10', text: 'text-purple-400', border: 'border-purple-500/20', label: 'Out for Delivery' },
  delivered: { bg: 'bg-emerald-500/10', text: 'text-emerald-400', border: 'border-emerald-500/20', label: 'Delivered' },
  delayed: { bg: 'bg-red-500/10', text: 'text-red-400', border: 'border-red-500/20', label: 'Delayed' },
};

const priorityConfig: Record<string, { bg: string; text: string }> = {
  low: { bg: 'bg-slate-500/10', text: 'text-slate-400' },
  medium: { bg: 'bg-blue-500/10', text: 'text-blue-400' },
  high: { bg: 'bg-amber-500/10', text: 'text-amber-400' },
  urgent: { bg: 'bg-red-500/10', text: 'text-red-400' },
};

export default function ShipmentsView() {
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [selectedShipment, setSelectedShipment] = useState<Shipment | null>(null);

  const filtered = shipments.filter(s => {
    const matchSearch = s.trackingId.toLowerCase().includes(searchTerm.toLowerCase()) ||
                       s.sender.toLowerCase().includes(searchTerm.toLowerCase()) ||
                       s.recipient.toLowerCase().includes(searchTerm.toLowerCase());
    const matchStatus = statusFilter === 'all' || s.status === statusFilter;
    return matchSearch && matchStatus;
  });

  return (
    <div className="flex h-full">
      <div className={`${selectedShipment ? 'w-1/2 lg:w-3/5' : 'w-full'} flex flex-col`}>
        {/* Filters */}
        <div className="p-4 border-b border-slate-800 space-y-3">
          <div className="relative">
            <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
            <input
              type="text"
              placeholder="Search by tracking ID, sender, or recipient..."
              value={searchTerm}
              onChange={e => setSearchTerm(e.target.value)}
              className="w-full bg-slate-800/60 border border-slate-700/50 rounded-xl pl-9 pr-4 py-2.5 text-sm text-slate-300 placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-blue-500/30"
            />
          </div>
          <div className="flex gap-2 overflow-x-auto pb-1">
            {['all', 'pending', 'picked_up', 'in_transit', 'out_for_delivery', 'delivered', 'delayed'].map(s => (
              <button
                key={s}
                onClick={() => setStatusFilter(s)}
                className={`px-3 py-1.5 rounded-lg text-xs font-medium capitalize whitespace-nowrap transition-all cursor-pointer
                  ${statusFilter === s 
                    ? 'bg-blue-600 text-white' 
                    : 'bg-slate-800 text-slate-400 hover:bg-slate-700'
                  }`}
              >
                {s.replace('_', ' ')}
              </button>
            ))}
          </div>
        </div>

        {/* Table */}
        <div className="flex-1 overflow-y-auto">
          <table className="w-full">
            <thead className="sticky top-0 bg-slate-900/95 backdrop-blur-sm">
              <tr className="border-b border-slate-800">
                <th className="text-left text-xs font-medium text-slate-500 px-4 py-3">Tracking ID</th>
                <th className="text-left text-xs font-medium text-slate-500 px-4 py-3 hidden lg:table-cell">Sender → Recipient</th>
                <th className="text-left text-xs font-medium text-slate-500 px-4 py-3">Status</th>
                <th className="text-left text-xs font-medium text-slate-500 px-4 py-3 hidden md:table-cell">Priority</th>
                <th className="text-left text-xs font-medium text-slate-500 px-4 py-3 hidden md:table-cell">Vehicle</th>
                <th className="text-left text-xs font-medium text-slate-500 px-4 py-3 hidden lg:table-cell">ETA</th>
                <th className="px-4 py-3"></th>
              </tr>
            </thead>
            <tbody>
              {filtered.map(s => {
                const status = statusConfig[s.status];
                const priority = priorityConfig[s.priority];
                const vehicle = s.vehicleId ? vehicles.find(v => v.id === s.vehicleId) : null;
                return (
                  <tr 
                    key={s.id} 
                    onClick={() => setSelectedShipment(s)}
                    className={`border-b border-slate-800/50 cursor-pointer transition-all ${
                      selectedShipment?.id === s.id 
                        ? 'bg-blue-600/5' 
                        : 'hover:bg-slate-800/30'
                    }`}
                  >
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-2">
                        <Package size={14} className={status.text} />
                        <span className="text-sm font-mono font-medium text-white">{s.trackingId}</span>
                      </div>
                    </td>
                    <td className="px-4 py-3 hidden lg:table-cell">
                      <div className="flex items-center gap-2 text-xs text-slate-400">
                        <span className="truncate max-w-[100px]">{s.sender}</span>
                        <ArrowRight size={10} className="text-slate-600 flex-shrink-0" />
                        <span className="truncate max-w-[100px]">{s.recipient}</span>
                      </div>
                    </td>
                    <td className="px-4 py-3">
                      <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium ${status.bg} ${status.text} border ${status.border}`}>
                        {status.label}
                      </span>
                    </td>
                    <td className="px-4 py-3 hidden md:table-cell">
                      <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium capitalize ${priority.bg} ${priority.text}`}>
                        {s.priority}
                      </span>
                    </td>
                    <td className="px-4 py-3 hidden md:table-cell">
                      <span className="text-xs text-slate-400">{vehicle?.name || '—'}</span>
                    </td>
                    <td className="px-4 py-3 hidden lg:table-cell">
                      <span className="text-xs text-slate-400">{s.estimatedDelivery.split(' ')[1] || '—'}</span>
                    </td>
                    <td className="px-4 py-3">
                      <ChevronRight size={14} className="text-slate-600" />
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Detail Panel */}
      {selectedShipment && (
        <div className="flex-1 border-l border-slate-800 overflow-y-auto p-6">
          <div className="max-w-lg mx-auto space-y-5">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-slate-500 mb-1">Shipment Details</p>
                <h2 className="text-lg font-bold text-white font-mono">{selectedShipment.trackingId}</h2>
              </div>
              <button 
                onClick={() => setSelectedShipment(null)}
                className="p-2 rounded-lg hover:bg-slate-800 text-slate-400 transition-all cursor-pointer"
              >
                <X size={16} />
              </button>
            </div>

            {/* Status Badge */}
            <div className={`inline-flex items-center gap-2 px-3 py-1.5 rounded-full ${statusConfig[selectedShipment.status].bg} ${statusConfig[selectedShipment.status].text} border ${statusConfig[selectedShipment.status].border}`}>
              {selectedShipment.status === 'delayed' ? <AlertTriangle size={14} /> : 
               selectedShipment.status === 'delivered' ? <CheckCircle2 size={14} /> : 
               <Package size={14} />}
              <span className="text-sm font-medium">{statusConfig[selectedShipment.status].label}</span>
            </div>

            {/* Route */}
            <div className="bg-slate-800/40 rounded-xl p-4 space-y-3">
              <div className="flex items-start gap-3">
                <div className="w-6 h-6 rounded-full bg-blue-500/20 flex items-center justify-center mt-0.5">
                  <div className="w-2 h-2 rounded-full bg-blue-500"></div>
                </div>
                <div>
                  <p className="text-xs text-slate-500">From</p>
                  <p className="text-sm text-white font-medium">{selectedShipment.sender}</p>
                  <p className="text-xs text-slate-400">{selectedShipment.origin}</p>
                </div>
              </div>
              <div className="ml-3 border-l-2 border-dashed border-slate-700 h-4"></div>
              <div className="flex items-start gap-3">
                <div className="w-6 h-6 rounded-full bg-emerald-500/20 flex items-center justify-center mt-0.5">
                  <div className="w-2 h-2 rounded-full bg-emerald-500"></div>
                </div>
                <div>
                  <p className="text-xs text-slate-500">To</p>
                  <p className="text-sm text-white font-medium">{selectedShipment.recipient}</p>
                  <p className="text-xs text-slate-400">{selectedShipment.destination}</p>
                </div>
              </div>
            </div>

            {/* Info Grid */}
            <div className="grid grid-cols-2 gap-3">
              <div className="bg-slate-800/40 rounded-xl p-3">
                <div className="flex items-center gap-1.5 text-slate-500 mb-1">
                  <Weight size={12} />
                  <span className="text-xs">Weight</span>
                </div>
                <p className="text-sm font-semibold text-white">{selectedShipment.weight} kg</p>
              </div>
              <div className="bg-slate-800/40 rounded-xl p-3">
                <div className="flex items-center gap-1.5 text-slate-500 mb-1">
                  <Clock size={12} />
                  <span className="text-xs">Est. Delivery</span>
                </div>
                <p className="text-sm font-semibold text-white">{selectedShipment.estimatedDelivery.split(' ')[1]}</p>
              </div>
              <div className="bg-slate-800/40 rounded-xl p-3">
                <div className="flex items-center gap-1.5 text-slate-500 mb-1">
                  <Truck size={12} />
                  <span className="text-xs">Vehicle</span>
                </div>
                <p className="text-sm font-semibold text-white">
                  {selectedShipment.vehicleId ? vehicles.find(v => v.id === selectedShipment.vehicleId)?.name || '—' : 'Unassigned'}
                </p>
              </div>
              <div className="bg-slate-800/40 rounded-xl p-3">
                <div className="flex items-center gap-1.5 text-slate-500 mb-1">
                  <AlertTriangle size={12} />
                  <span className="text-xs">Priority</span>
                </div>
                <p className={`text-sm font-semibold capitalize ${priorityConfig[selectedShipment.priority].text}`}>
                  {selectedShipment.priority}
                </p>
              </div>
            </div>

            {/* Timeline */}
            <div className="bg-slate-900/60 border border-slate-800 rounded-2xl p-5">
              <h3 className="text-sm font-semibold text-white mb-4">Tracking Timeline</h3>
              <div className="space-y-4">
                {selectedShipment.updates.map((update, idx) => (
                  <div key={idx} className="flex gap-3">
                    <div className="flex flex-col items-center">
                      <div className={`w-3 h-3 rounded-full flex-shrink-0 ${
                        idx === selectedShipment.updates.length - 1 
                          ? 'bg-blue-500 ring-4 ring-blue-500/20' 
                          : 'bg-slate-600'
                      }`}></div>
                      {idx < selectedShipment.updates.length - 1 && (
                        <div className="w-px h-full bg-slate-700 mt-1"></div>
                      )}
                    </div>
                    <div className="pb-4">
                      <p className="text-sm font-medium text-white">{update.status}</p>
                      <p className="text-xs text-slate-500 mt-0.5">
                        {update.timestamp} • {update.location}
                      </p>
                      {update.note && (
                        <p className="text-xs text-amber-400/80 mt-1 italic">{update.note}</p>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
