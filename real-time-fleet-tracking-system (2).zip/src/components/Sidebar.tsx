import { 
  LayoutDashboard, Map, Truck, Package, Route, BarChart3, 
  Bell, Settings, ChevronLeft, ChevronRight, Zap
} from 'lucide-react';
import { TabType } from '../data/types';

interface SidebarProps {
  activeTab: TabType;
  onTabChange: (tab: TabType) => void;
  collapsed: boolean;
  onToggle: () => void;
  alertCount: number;
}

const navItems: { id: TabType; label: string; icon: React.ReactNode }[] = [
  { id: 'dashboard', label: 'Dashboard', icon: <LayoutDashboard size={20} /> },
  { id: 'map', label: 'Live Map', icon: <Map size={20} /> },
  { id: 'fleet', label: 'Fleet', icon: <Truck size={20} /> },
  { id: 'shipments', label: 'Shipments', icon: <Package size={20} /> },
  { id: 'routes', label: 'Routes', icon: <Route size={20} /> },
  { id: 'analytics', label: 'Analytics', icon: <BarChart3 size={20} /> },
];

export default function Sidebar({ activeTab, onTabChange, collapsed, onToggle, alertCount }: SidebarProps) {
  return (
    <div className={`flex flex-col bg-slate-900 border-r border-slate-800 transition-all duration-300 ${collapsed ? 'w-[68px]' : 'w-[240px]'}`}>
      {/* Logo */}
      <div className="flex items-center gap-3 px-4 h-16 border-b border-slate-800 flex-shrink-0">
        <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-blue-500 to-cyan-400 flex items-center justify-center flex-shrink-0 shadow-lg shadow-blue-500/20">
          <Zap size={20} className="text-white" />
        </div>
        {!collapsed && (
          <div className="overflow-hidden">
            <h1 className="text-base font-bold text-white tracking-tight">FleetPulse</h1>
            <p className="text-[10px] text-slate-500 uppercase tracking-widest">Logistics Platform</p>
          </div>
        )}
      </div>

      {/* Navigation */}
      <nav className="flex-1 py-4 px-2 space-y-1 overflow-y-auto">
        {navItems.map((item) => (
          <button
            key={item.id}
            onClick={() => onTabChange(item.id)}
            className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-all duration-200 cursor-pointer
              ${activeTab === item.id
                ? 'bg-blue-600/15 text-blue-400 shadow-lg shadow-blue-500/5'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
              }
              ${collapsed ? 'justify-center' : ''}
            `}
            title={collapsed ? item.label : undefined}
          >
            <span className={`flex-shrink-0 ${activeTab === item.id ? 'text-blue-400' : ''}`}>
              {item.icon}
            </span>
            {!collapsed && <span>{item.label}</span>}
          </button>
        ))}
      </nav>

      {/* Bottom section */}
      <div className="px-2 pb-4 space-y-1 border-t border-slate-800 pt-4">
        <button className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm text-slate-400 hover:text-slate-200 hover:bg-slate-800/60 transition-all relative cursor-pointer ${collapsed ? 'justify-center' : ''}`}>
          <Bell size={20} />
          {!collapsed && <span>Alerts</span>}
          {alertCount > 0 && (
            <span className={`absolute ${collapsed ? 'top-1 right-1' : 'right-3'} bg-red-500 text-white text-[10px] font-bold rounded-full min-w-[18px] h-[18px] flex items-center justify-center px-1`}>
              {alertCount}
            </span>
          )}
        </button>
        <button className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm text-slate-400 hover:text-slate-200 hover:bg-slate-800/60 transition-all cursor-pointer ${collapsed ? 'justify-center' : ''}`}>
          <Settings size={20} />
          {!collapsed && <span>Settings</span>}
        </button>
        <button
          onClick={onToggle}
          className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm text-slate-400 hover:text-slate-200 hover:bg-slate-800/60 transition-all cursor-pointer ${collapsed ? 'justify-center' : ''}`}
        >
          {collapsed ? <ChevronRight size={20} /> : <ChevronLeft size={20} />}
          {!collapsed && <span>Collapse</span>}
        </button>
      </div>
    </div>
  );
}
