import { useEffect, useState, useMemo } from 'react';
import { MapContainer, TileLayer, Marker, Popup, Polyline, useMap } from 'react-leaflet';
import L from 'leaflet';
import { Layers, Maximize2 } from 'lucide-react';
import { vehicles, routes } from '../data/mockData';
import { Vehicle } from '../data/types';

// Custom vehicle icon creator
function createVehicleIcon(vehicle: Vehicle): L.DivIcon {
  const statusColor = vehicle.status === 'active' ? '#22c55e' 
    : vehicle.status === 'idle' ? '#f59e0b' 
    : vehicle.status === 'maintenance' ? '#3b82f6' 
    : '#64748b';
  
  const bgColor = vehicle.status === 'active' ? '#052e16' 
    : vehicle.status === 'idle' ? '#451a03' 
    : vehicle.status === 'maintenance' ? '#172554' 
    : '#1e293b';

  const emoji = vehicle.type === 'truck' ? '🚛' : vehicle.type === 'van' ? '🚐' : '🏍️';
  
  return L.divIcon({
    className: 'custom-vehicle-marker',
    html: `
      <div style="
        width: 40px; height: 40px; 
        background: ${bgColor}; 
        border: 2px solid ${statusColor}; 
        border-radius: 50%; 
        display: flex; align-items: center; justify-content: center;
        box-shadow: 0 0 12px ${statusColor}40;
        font-size: 18px;
        position: relative;
      ">
        ${emoji}
        ${vehicle.status === 'active' ? `<div style="position:absolute;bottom:-2px;right:-2px;width:10px;height:10px;background:${statusColor};border-radius:50%;border:2px solid ${bgColor};"></div>` : ''}
      </div>
    `,
    iconSize: [40, 40],
    iconAnchor: [20, 20],
    popupAnchor: [0, -24],
  });
}

function createStopIcon(completed: boolean): L.DivIcon {
  return L.divIcon({
    className: 'custom-stop-marker',
    html: `
      <div style="
        width: 24px; height: 24px;
        background: ${completed ? '#052e16' : '#1e293b'};
        border: 2px solid ${completed ? '#22c55e' : '#f59e0b'};
        border-radius: 50%;
        display: flex; align-items: center; justify-content: center;
        font-size: 11px;
        box-shadow: 0 0 8px ${completed ? '#22c55e40' : '#f59e0b40'};
      ">
        ${completed ? '✓' : '◉'}
      </div>
    `,
    iconSize: [24, 24],
    iconAnchor: [12, 12],
    popupAnchor: [0, -16],
  });
}

function MapController({ center, zoom }: { center: [number, number]; zoom: number }) {
  const map = useMap();
  useEffect(() => {
    map.setView(center, zoom, { animate: true });
  }, [center, zoom, map]);
  return null;
}

interface LiveMapProps {
  selectedVehicle?: string | null;
  onSelectVehicle?: (id: string) => void;
  compact?: boolean;
}

export default function LiveMap({ selectedVehicle, onSelectVehicle, compact = false }: LiveMapProps) {
  const [showRoutes, setShowRoutes] = useState(true);
  const [mapCenter, setMapCenter] = useState<[number, number]>([40.7528, -73.9765]);
  const [mapZoom, setMapZoom] = useState(13);
  const [filter, setFilter] = useState<string>('all');

  // Simulated movement
  const [vehiclePositions, setVehiclePositions] = useState(
    vehicles.map(v => ({ id: v.id, lat: v.lat, lng: v.lng }))
  );

  useEffect(() => {
    const interval = setInterval(() => {
      setVehiclePositions(prev => prev.map(pos => {
        const vehicle = vehicles.find(v => v.id === pos.id);
        if (vehicle?.status !== 'active') return pos;
        return {
          ...pos,
          lat: pos.lat + (Math.random() - 0.5) * 0.001,
          lng: pos.lng + (Math.random() - 0.5) * 0.001,
        };
      }));
    }, 3000);
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    if (selectedVehicle) {
      const pos = vehiclePositions.find(p => p.id === selectedVehicle);
      if (pos) {
        setMapCenter([pos.lat, pos.lng]);
        setMapZoom(15);
      }
    }
  }, [selectedVehicle]);

  const filteredVehicles = useMemo(() => {
    if (filter === 'all') return vehicles;
    return vehicles.filter(v => v.status === filter);
  }, [filter]);

  const routeColors = ['#3b82f6', '#22c55e', '#f59e0b', '#ef4444', '#8b5cf6'];

  return (
    <div className={`relative ${compact ? 'h-full' : 'h-full'} flex flex-col`}>
      {/* Map Controls */}
      {!compact && (
        <div className="absolute top-4 left-4 z-[1000] flex flex-col gap-2">
          <div className="bg-slate-900/90 backdrop-blur-xl border border-slate-700/50 rounded-xl p-1 flex gap-1">
            {['all', 'active', 'idle', 'maintenance'].map(f => (
              <button
                key={f}
                onClick={() => setFilter(f)}
                className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all capitalize cursor-pointer
                  ${filter === f 
                    ? 'bg-blue-600 text-white shadow-lg shadow-blue-500/20' 
                    : 'text-slate-400 hover:text-white hover:bg-slate-800'
                  }`}
              >
                {f}
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Toggle Routes */}
      <div className={`absolute ${compact ? 'top-2 right-2' : 'top-4 right-4'} z-[1000] flex flex-col gap-2`}>
        <button
          onClick={() => setShowRoutes(!showRoutes)}
          className={`p-2 rounded-xl border transition-all cursor-pointer ${
            showRoutes 
              ? 'bg-blue-600/20 border-blue-500/30 text-blue-400' 
              : 'bg-slate-900/90 border-slate-700/50 text-slate-400'
          }`}
          title="Toggle Routes"
        >
          <Layers size={16} />
        </button>
        {!compact && (
          <button
            onClick={() => { setMapCenter([40.7528, -73.9765]); setMapZoom(13); }}
            className="p-2 rounded-xl bg-slate-900/90 border border-slate-700/50 text-slate-400 hover:text-white transition-all cursor-pointer"
            title="Reset View"
          >
            <Maximize2 size={16} />
          </button>
        )}
      </div>

      {/* Vehicle Info Panel */}
      {selectedVehicle && !compact && (
        <div className="absolute bottom-4 left-4 z-[1000] bg-slate-900/95 backdrop-blur-xl border border-slate-700/50 rounded-2xl p-4 w-72 shadow-2xl">
          {(() => {
            const v = vehicles.find(vh => vh.id === selectedVehicle);
            if (!v) return null;
            const route = routes.find(r => r.vehicleId === v.id);
            return (
              <div>
                <div className="flex items-center gap-3 mb-3">
                  <div className="w-10 h-10 rounded-full bg-slate-800 border border-slate-700 flex items-center justify-center text-sm font-bold text-white">
                    {v.driverAvatar}
                  </div>
                  <div>
                    <p className="text-sm font-semibold text-white">{v.name}</p>
                    <p className="text-xs text-slate-400">{v.driver}</p>
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <div className="bg-slate-800/60 rounded-lg p-2">
                    <p className="text-[10px] text-slate-500">Speed</p>
                    <p className="text-sm font-semibold text-white">{v.speed} mph</p>
                  </div>
                  <div className="bg-slate-800/60 rounded-lg p-2">
                    <p className="text-[10px] text-slate-500">Fuel</p>
                    <p className="text-sm font-semibold text-white">{v.fuel}%</p>
                  </div>
                  <div className="bg-slate-800/60 rounded-lg p-2">
                    <p className="text-[10px] text-slate-500">Deliveries</p>
                    <p className="text-sm font-semibold text-white">{v.deliveriesCompleted}/{v.deliveriesTotal}</p>
                  </div>
                  <div className="bg-slate-800/60 rounded-lg p-2">
                    <p className="text-[10px] text-slate-500">ETA</p>
                    <p className="text-sm font-semibold text-white">{v.eta || '—'}</p>
                  </div>
                </div>
                {route && (
                  <div className="mt-3 pt-3 border-t border-slate-800">
                    <p className="text-xs text-slate-500 mb-1">Current Route</p>
                    <p className="text-sm font-medium text-blue-400">{route.name}</p>
                    <p className="text-xs text-slate-500">{route.distance} mi • ~{route.estimatedTime} min</p>
                  </div>
                )}
              </div>
            );
          })()}
        </div>
      )}

      <MapContainer
        center={mapCenter}
        zoom={mapZoom}
        style={{ width: '100%', height: '100%' }}
        zoomControl={!compact}
      >
        <MapController center={mapCenter} zoom={mapZoom} />
        <TileLayer
          attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OSM</a>'
          url="https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png"
        />
        
        {/* Routes */}
        {showRoutes && routes.map((route, idx) => {
          const routeVehicle = filteredVehicles.find(v => v.id === route.vehicleId);
          if (!routeVehicle) return null;
          return (
            <Polyline
              key={route.id}
              positions={route.points.map(p => [p.lat, p.lng] as [number, number])}
              color={routeColors[idx % routeColors.length]}
              weight={3}
              opacity={selectedVehicle === route.vehicleId ? 0.9 : 0.4}
              dashArray={route.status === 'active' ? undefined : '8 8'}
            />
          );
        })}

        {/* Route Stops */}
        {showRoutes && routes.map(route => {
          const routeVehicle = filteredVehicles.find(v => v.id === route.vehicleId);
          if (!routeVehicle) return null;
          return route.stops.map(stop => (
            <Marker
              key={stop.id}
              position={[stop.lat, stop.lng]}
              icon={createStopIcon(stop.status === 'completed')}
            >
              <Popup>
                <div className="text-sm">
                  <p className="font-semibold text-white">{stop.name}</p>
                  <p className="text-slate-400 text-xs mt-1">{stop.address}</p>
                  <div className="flex items-center gap-2 mt-2">
                    <span className={`text-xs px-2 py-0.5 rounded-full ${
                      stop.status === 'completed' 
                        ? 'bg-emerald-500/20 text-emerald-400' 
                        : 'bg-amber-500/20 text-amber-400'
                    }`}>
                      {stop.status}
                    </span>
                    <span className="text-xs text-slate-400">
                      {stop.actualTime || stop.scheduledTime}
                    </span>
                  </div>
                </div>
              </Popup>
            </Marker>
          ));
        })}

        {/* Vehicle Markers */}
        {filteredVehicles.map(vehicle => {
          const pos = vehiclePositions.find(p => p.id === vehicle.id);
          if (!pos) return null;
          return (
            <Marker
              key={vehicle.id}
              position={[pos.lat, pos.lng]}
              icon={createVehicleIcon(vehicle)}
              eventHandlers={{
                click: () => onSelectVehicle?.(vehicle.id),
              }}
            >
              <Popup>
                <div className="text-sm min-w-[180px]">
                  <p className="font-semibold text-white text-base">{vehicle.name}</p>
                  <p className="text-slate-400 text-xs">{vehicle.driver}</p>
                  <div className="grid grid-cols-2 gap-x-4 gap-y-1 mt-2">
                    <span className="text-slate-500 text-xs">Status</span>
                    <span className={`text-xs font-medium capitalize ${
                      vehicle.status === 'active' ? 'text-emerald-400' 
                      : vehicle.status === 'idle' ? 'text-amber-400' 
                      : 'text-slate-400'
                    }`}>{vehicle.status}</span>
                    <span className="text-slate-500 text-xs">Speed</span>
                    <span className="text-white text-xs">{vehicle.speed} mph</span>
                    <span className="text-slate-500 text-xs">Fuel</span>
                    <span className="text-white text-xs">{vehicle.fuel}%</span>
                  </div>
                </div>
              </Popup>
            </Marker>
          );
        })}
      </MapContainer>
    </div>
  );
}
