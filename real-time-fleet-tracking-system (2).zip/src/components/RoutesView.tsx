import { useState } from 'react';
import { MapPin, Clock, CheckCircle2, Circle, Navigation, Zap } from 'lucide-react';
import { routes, vehicles } from '../data/mockData';

const statusConfig: Record<string, { bg: string; text: string; border: string }> = {
  planned: { bg: 'bg-slate-500/10', text: 'text-slate-400', border: 'border-slate-500/20' },
  active: { bg: 'bg-emerald-500/10', text: 'text-emerald-400', border: 'border-emerald-500/20' },
  completed: { bg: 'bg-blue-500/10', text: 'text-blue-400', border: 'border-blue-500/20' },
};

export default function RoutesView() {
  const [selectedRoute, setSelectedRoute] = useState<string | null>(null);
  const route = selectedRoute ? routes.find(r => r.id === selectedRoute) : null;

  return (
    <div className="flex h-full">
      {/* Route List */}
      <div className={`${route ? 'w-2/5' : 'w-full'} border-r border-slate-800 flex flex-col`}>
        <div className="p-4 border-b border-slate-800">
          <div className="flex items-center justify-between mb-3">
            <h3 className="text-sm font-semibold text-white">Active Routes</h3>
            <span className="text-xs text-slate-500">{routes.length} routes</span>
          </div>
          <button className="w-full flex items-center justify-center gap-2 px-4 py-2.5 bg-blue-600 hover:bg-blue-700 text-white text-sm font-medium rounded-xl transition-all cursor-pointer">
            <Zap size={16} />
            Optimize All Routes
          </button>
        </div>

        <div className="flex-1 overflow-y-auto p-4 space-y-3">
          {routes.map(r => {
            const vehicle = vehicles.find(v => v.id === r.vehicleId);
            const completedStops = r.stops.filter(s => s.status === 'completed').length;
            const status = statusConfig[r.status];
            
            return (
              <div
                key={r.id}
                onClick={() => setSelectedRoute(r.id)}
                className={`p-4 rounded-2xl border cursor-pointer transition-all ${
                  selectedRoute === r.id 
                    ? 'bg-blue-600/10 border-blue-500/30' 
                    : 'bg-slate-900/60 border-slate-800 hover:border-slate-700'
                }`}
              >
                <div className="flex items-start justify-between mb-3">
                  <div>
                    <h4 className="text-sm font-semibold text-white">{r.name}</h4>
                    <p className="text-xs text-slate-500 mt-0.5">{vehicle?.name} • {vehicle?.driver}</p>
                  </div>
                  <span className={`px-2 py-0.5 rounded-full text-xs font-medium capitalize ${status.bg} ${status.text} border ${status.border}`}>
                    {r.status}
                  </span>
                </div>

                <div className="flex items-center gap-4 text-xs text-slate-400 mb-3">
                  <span className="flex items-center gap-1">
                    <Navigation size={12} />
                    {r.distance} mi
                  </span>
                  <span className="flex items-center gap-1">
                    <Clock size={12} />
                    ~{r.estimatedTime} min
                  </span>
                  <span className="flex items-center gap-1">
                    <MapPin size={12} />
                    {r.stops.length} stops
                  </span>
                </div>

                <div className="flex items-center gap-2">
                  <div className="flex-1 h-1.5 bg-slate-800 rounded-full overflow-hidden">
                    <div 
                      className="h-full bg-gradient-to-r from-blue-500 to-cyan-400 rounded-full"
                      style={{ width: `${(completedStops / r.stops.length) * 100}%` }}
                    />
                  </div>
                  <span className="text-xs text-slate-500 whitespace-nowrap">{completedStops}/{r.stops.length}</span>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Route Detail */}
      {route && (
        <div className="flex-1 overflow-y-auto p-6">
          <div className="max-w-2xl mx-auto space-y-6">
            <div>
              <h2 className="text-xl font-bold text-white">{route.name}</h2>
              <p className="text-sm text-slate-400 mt-1">
                {vehicles.find(v => v.id === route.vehicleId)?.name} • {vehicles.find(v => v.id === route.vehicleId)?.driver}
              </p>
            </div>

            {/* Route Stats */}
            <div className="grid grid-cols-3 gap-3">
              <div className="bg-slate-800/40 rounded-xl p-4 text-center">
                <Navigation size={20} className="text-blue-400 mx-auto mb-2" />
                <p className="text-lg font-bold text-white">{route.distance} mi</p>
                <p className="text-xs text-slate-500">Total Distance</p>
              </div>
              <div className="bg-slate-800/40 rounded-xl p-4 text-center">
                <Clock size={20} className="text-purple-400 mx-auto mb-2" />
                <p className="text-lg font-bold text-white">{route.estimatedTime} min</p>
                <p className="text-xs text-slate-500">Est. Duration</p>
              </div>
              <div className="bg-slate-800/40 rounded-xl p-4 text-center">
                <MapPin size={20} className="text-emerald-400 mx-auto mb-2" />
                <p className="text-lg font-bold text-white">{route.stops.length}</p>
                <p className="text-xs text-slate-500">Total Stops</p>
              </div>
            </div>

            {/* Route Optimization Banner */}
            <div className="bg-gradient-to-r from-blue-600/10 to-cyan-600/10 border border-blue-500/20 rounded-2xl p-4 flex items-center gap-4">
              <div className="p-3 rounded-xl bg-blue-500/10">
                <Zap size={20} className="text-blue-400" />
              </div>
              <div className="flex-1">
                <p className="text-sm font-semibold text-white">Route Optimized</p>
                <p className="text-xs text-slate-400">This route saves ~12 min vs. standard routing</p>
              </div>
              <span className="text-xs font-bold text-emerald-400 bg-emerald-500/10 px-2 py-1 rounded-full">-15%</span>
            </div>

            {/* Stops Timeline */}
            <div className="bg-slate-900/60 border border-slate-800 rounded-2xl p-5">
              <h3 className="text-sm font-semibold text-white mb-4">Route Stops</h3>
              <div className="space-y-0">
                {route.stops.map((stop, idx) => (
                  <div key={stop.id} className="flex gap-3">
                    <div className="flex flex-col items-center">
                      {stop.status === 'completed' ? (
                        <CheckCircle2 size={20} className="text-emerald-400 flex-shrink-0" />
                      ) : (
                        <Circle size={20} className="text-slate-600 flex-shrink-0" />
                      )}
                      {idx < route.stops.length - 1 && (
                        <div className={`w-px flex-1 mt-1 mb-1 ${stop.status === 'completed' ? 'bg-emerald-500/30' : 'bg-slate-700'}`}></div>
                      )}
                    </div>
                    <div className={`pb-6 flex-1 ${stop.status === 'completed' ? '' : 'opacity-70'}`}>
                      <div className="flex items-center gap-2">
                        <span className={`text-xs px-1.5 py-0.5 rounded ${
                          stop.type === 'pickup' ? 'bg-blue-500/10 text-blue-400' : 'bg-emerald-500/10 text-emerald-400'
                        }`}>
                          {stop.type}
                        </span>
                        <span className="text-xs text-slate-500">
                          {stop.actualTime ? `${stop.actualTime} (scheduled ${stop.scheduledTime})` : `Scheduled: ${stop.scheduledTime}`}
                        </span>
                      </div>
                      <p className="text-sm font-medium text-white mt-1">{stop.name}</p>
                      <p className="text-xs text-slate-500">{stop.address}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
