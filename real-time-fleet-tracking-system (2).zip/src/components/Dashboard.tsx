import { Truck, Package, Route, AlertTriangle, CheckCircle2, Fuel, Gauge } from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, AreaChart, Area, PieChart, Pie, Cell } from 'recharts';
import StatCard from './StatCard';
import { vehicles, shipments, analyticsData } from '../data/mockData';
import { Vehicle } from '../data/types';

const statusColors: Record<string, string> = {
  active: 'bg-emerald-500',
  idle: 'bg-amber-500',
  maintenance: 'bg-blue-500',
  offline: 'bg-slate-500',
};

const statusTextColors: Record<string, string> = {
  active: 'text-emerald-400',
  idle: 'text-amber-400',
  maintenance: 'text-blue-400',
  offline: 'text-slate-400',
};

const pieColors = ['#3b82f6', '#f59e0b', '#8b5cf6', '#64748b'];

function VehicleRow({ vehicle }: { vehicle: Vehicle }) {
  return (
    <div className="flex items-center gap-3 p-3 rounded-xl hover:bg-slate-800/50 transition-all group">
      <div className="w-9 h-9 rounded-full bg-slate-800 border border-slate-700 flex items-center justify-center text-xs font-bold text-slate-300">
        {vehicle.driverAvatar}
      </div>
      <div className="flex-1 min-w-0">
        <p className="text-sm font-medium text-slate-200 truncate">{vehicle.name}</p>
        <p className="text-xs text-slate-500">{vehicle.driver}</p>
      </div>
      <div className="flex items-center gap-2">
        <span className={`inline-flex items-center gap-1.5 text-xs font-medium ${statusTextColors[vehicle.status]}`}>
          <span className={`w-1.5 h-1.5 rounded-full ${statusColors[vehicle.status]}`}></span>
          {vehicle.status}
        </span>
        {vehicle.speed > 0 && (
          <span className="text-xs text-slate-500">{vehicle.speed} mph</span>
        )}
      </div>
    </div>
  );
}

const CustomTooltip = ({ active, payload, label }: any) => {
  if (active && payload && payload.length) {
    return (
      <div className="bg-slate-800 border border-slate-700 rounded-xl px-4 py-3 shadow-2xl">
        <p className="text-xs text-slate-400 mb-1">{label}</p>
        {payload.map((entry: any, index: number) => (
          <p key={index} className="text-sm font-semibold" style={{ color: entry.color }}>
            {entry.name}: {entry.value}
          </p>
        ))}
      </div>
    );
  }
  return null;
};

export default function Dashboard() {
  const activeVehicles = vehicles.filter(v => v.status === 'active').length;
  const totalDeliveries = vehicles.reduce((a, v) => a + v.deliveriesCompleted, 0);
  const totalShipments = shipments.length;
  const delayedShipments = shipments.filter(s => s.status === 'delayed').length;
  const deliveredShipments = shipments.filter(s => s.status === 'delivered').length;
  const avgFuel = Math.round(vehicles.reduce((a, v) => a + v.fuel, 0) / vehicles.length);

  return (
    <div className="p-6 space-y-6 overflow-y-auto h-full">
      {/* Stats Grid */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard
          title="Active Vehicles"
          value={`${activeVehicles}/${vehicles.length}`}
          change={12}
          icon={<Truck size={20} />}
          color="blue"
          subtitle="Currently on route"
        />
        <StatCard
          title="Today's Deliveries"
          value={totalDeliveries}
          change={8}
          icon={<Package size={20} />}
          color="green"
          subtitle={`${deliveredShipments} completed`}
        />
        <StatCard
          title="Active Shipments"
          value={totalShipments}
          change={-3}
          icon={<Route size={20} />}
          color="purple"
          subtitle={`${delayedShipments} delayed`}
        />
        <StatCard
          title="Avg Fleet Fuel"
          value={`${avgFuel}%`}
          change={5}
          icon={<Fuel size={20} />}
          color="cyan"
          subtitle="Across all vehicles"
        />
      </div>

      {/* Charts Row */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Deliveries Chart */}
        <div className="lg:col-span-2 bg-slate-900/60 border border-slate-800 rounded-2xl p-5">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-sm font-semibold text-white">Deliveries This Week</h3>
              <p className="text-xs text-slate-500">On-time vs total deliveries</p>
            </div>
            <div className="flex items-center gap-4 text-xs">
              <span className="flex items-center gap-1.5"><span className="w-2.5 h-2.5 rounded-sm bg-blue-500"></span>Total</span>
              <span className="flex items-center gap-1.5"><span className="w-2.5 h-2.5 rounded-sm bg-emerald-500"></span>On-Time</span>
            </div>
          </div>
          <ResponsiveContainer width="100%" height={220}>
            <BarChart data={analyticsData.deliveriesPerDay} barGap={4}>
              <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
              <XAxis dataKey="date" tick={{ fill: '#64748b', fontSize: 12 }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fill: '#64748b', fontSize: 12 }} axisLine={false} tickLine={false} />
              <Tooltip content={<CustomTooltip />} />
              <Bar dataKey="count" name="Total" fill="#3b82f6" radius={[6, 6, 0, 0]} />
              <Bar dataKey="onTime" name="On-Time" fill="#22c55e" radius={[6, 6, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* Fleet Utilization Pie */}
        <div className="bg-slate-900/60 border border-slate-800 rounded-2xl p-5">
          <h3 className="text-sm font-semibold text-white mb-1">Fleet Utilization</h3>
          <p className="text-xs text-slate-500 mb-4">Current fleet status breakdown</p>
          <ResponsiveContainer width="100%" height={180}>
            <PieChart>
              <Pie
                data={analyticsData.fleetUtilization}
                cx="50%"
                cy="50%"
                innerRadius={50}
                outerRadius={80}
                paddingAngle={3}
                dataKey="value"
              >
                {analyticsData.fleetUtilization.map((_, index) => (
                  <Cell key={`cell-${index}`} fill={pieColors[index]} />
                ))}
              </Pie>
              <Tooltip content={<CustomTooltip />} />
            </PieChart>
          </ResponsiveContainer>
          <div className="grid grid-cols-2 gap-2 mt-2">
            {analyticsData.fleetUtilization.map((item, index) => (
              <div key={item.name} className="flex items-center gap-2 text-xs">
                <span className="w-2 h-2 rounded-full" style={{ backgroundColor: pieColors[index] }}></span>
                <span className="text-slate-400">{item.name}</span>
                <span className="text-white font-medium ml-auto">{item.value}%</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Bottom Row */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Revenue Chart */}
        <div className="lg:col-span-2 bg-slate-900/60 border border-slate-800 rounded-2xl p-5">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-sm font-semibold text-white">Revenue Overview</h3>
              <p className="text-xs text-slate-500">Last 6 months performance</p>
            </div>
            <div className="flex items-center gap-4 text-xs">
              <span className="flex items-center gap-1.5"><span className="w-2.5 h-2.5 rounded-sm bg-blue-500"></span>Revenue</span>
              <span className="flex items-center gap-1.5"><span className="w-2.5 h-2.5 rounded-sm bg-purple-500"></span>Profit</span>
            </div>
          </div>
          <ResponsiveContainer width="100%" height={220}>
            <AreaChart data={analyticsData.monthlyRevenue}>
              <defs>
                <linearGradient id="colorRevenue" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.2} />
                  <stop offset="95%" stopColor="#3b82f6" stopOpacity={0} />
                </linearGradient>
                <linearGradient id="colorProfit" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#8b5cf6" stopOpacity={0.2} />
                  <stop offset="95%" stopColor="#8b5cf6" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
              <XAxis dataKey="month" tick={{ fill: '#64748b', fontSize: 12 }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fill: '#64748b', fontSize: 12 }} axisLine={false} tickLine={false} tickFormatter={(v) => `$${v / 1000}k`} />
              <Tooltip content={<CustomTooltip />} />
              <Area type="monotone" dataKey="revenue" name="Revenue" stroke="#3b82f6" fill="url(#colorRevenue)" strokeWidth={2} />
              <Area type="monotone" dataKey="profit" name="Profit" stroke="#8b5cf6" fill="url(#colorProfit)" strokeWidth={2} />
            </AreaChart>
          </ResponsiveContainer>
        </div>

        {/* Live Fleet Status */}
        <div className="bg-slate-900/60 border border-slate-800 rounded-2xl p-5">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-sm font-semibold text-white">Fleet Status</h3>
              <p className="text-xs text-slate-500">Real-time vehicle updates</p>
            </div>
            <div className="flex items-center gap-1.5 px-2 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/20">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></span>
              <span className="text-[10px] font-medium text-emerald-400">LIVE</span>
            </div>
          </div>
          <div className="space-y-1 max-h-[280px] overflow-y-auto">
            {vehicles.map(v => (
              <VehicleRow key={v.id} vehicle={v} />
            ))}
          </div>
        </div>
      </div>

      {/* Alerts */}
      <div className="bg-slate-900/60 border border-slate-800 rounded-2xl p-5">
        <h3 className="text-sm font-semibold text-white mb-4 flex items-center gap-2">
          <AlertTriangle size={16} className="text-amber-400" />
          Active Alerts
        </h3>
        <div className="space-y-3">
          <div className="flex items-start gap-3 p-3 rounded-xl bg-red-500/5 border border-red-500/10">
            <div className="p-1.5 rounded-lg bg-red-500/10 text-red-400 mt-0.5">
              <AlertTriangle size={14} />
            </div>
            <div className="flex-1">
              <p className="text-sm font-medium text-red-300">Shipment FP-2024-001851 Delayed</p>
              <p className="text-xs text-slate-500 mt-0.5">Traffic congestion on BQE — ETA pushed by 45 min</p>
            </div>
            <span className="text-[10px] text-slate-500">9:30 AM</span>
          </div>
          <div className="flex items-start gap-3 p-3 rounded-xl bg-amber-500/5 border border-amber-500/10">
            <div className="p-1.5 rounded-lg bg-amber-500/10 text-amber-400 mt-0.5">
              <Fuel size={14} />
            </div>
            <div className="flex-1">
              <p className="text-sm font-medium text-amber-300">Low Fuel Warning — Van Hotel-11</p>
              <p className="text-xs text-slate-500 mt-0.5">Fuel level at 15% — needs refueling before next route</p>
            </div>
            <span className="text-[10px] text-slate-500">8:15 AM</span>
          </div>
          <div className="flex items-start gap-3 p-3 rounded-xl bg-blue-500/5 border border-blue-500/10">
            <div className="p-1.5 rounded-lg bg-blue-500/10 text-blue-400 mt-0.5">
              <Gauge size={14} />
            </div>
            <div className="flex-1">
              <p className="text-sm font-medium text-blue-300">Maintenance Due — Van Echo-05</p>
              <p className="text-xs text-slate-500 mt-0.5">Scheduled maintenance check at 55,000 miles overdue</p>
            </div>
            <span className="text-[10px] text-slate-500">Yesterday</span>
          </div>
          <div className="flex items-start gap-3 p-3 rounded-xl bg-emerald-500/5 border border-emerald-500/10">
            <div className="p-1.5 rounded-lg bg-emerald-500/10 text-emerald-400 mt-0.5">
              <CheckCircle2 size={14} />
            </div>
            <div className="flex-1">
              <p className="text-sm font-medium text-emerald-300">All morning deliveries completed on time</p>
              <p className="text-xs text-slate-500 mt-0.5">12 deliveries fulfilled ahead of schedule</p>
            </div>
            <span className="text-[10px] text-slate-500">11:00 AM</span>
          </div>
        </div>
      </div>
    </div>
  );
}
