import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, AreaChart, Area, LineChart, Line, RadarChart, Radar, PolarGrid, PolarAngleAxis, PolarRadiusAxis } from 'recharts';
import { TrendingUp, Truck, DollarSign, Star, Target, Award } from 'lucide-react';
import StatCard from './StatCard';
import { analyticsData } from '../data/mockData';

const CustomTooltip = ({ active, payload, label }: any) => {
  if (active && payload && payload.length) {
    return (
      <div className="bg-slate-800 border border-slate-700 rounded-xl px-4 py-3 shadow-2xl">
        <p className="text-xs text-slate-400 mb-1">{label}</p>
        {payload.map((entry: any, index: number) => (
          <p key={index} className="text-sm font-semibold" style={{ color: entry.color }}>
            {entry.name}: {typeof entry.value === 'number' && entry.value > 1000 ? `$${(entry.value / 1000).toFixed(0)}k` : entry.value}
          </p>
        ))}
      </div>
    );
  }
  return null;
};

const ratingData = analyticsData.performanceByDriver.map(d => ({
  name: d.driver.split(' ')[0],
  deliveries: d.deliveries,
  rating: d.rating * 20,
  onTime: d.onTimeRate,
}));

export default function AnalyticsView() {
  const totalDeliveries = analyticsData.performanceByDriver.reduce((a, d) => a + d.deliveries, 0);
  const avgRating = (analyticsData.performanceByDriver.reduce((a, d) => a + d.rating, 0) / analyticsData.performanceByDriver.length).toFixed(1);
  const avgOnTime = Math.round(analyticsData.performanceByDriver.reduce((a, d) => a + d.onTimeRate, 0) / analyticsData.performanceByDriver.length);
  const totalRevenue = analyticsData.monthlyRevenue.reduce((a, m) => a + m.revenue, 0);

  return (
    <div className="p-6 space-y-6 overflow-y-auto h-full">
      {/* Top Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard
          title="Total Deliveries"
          value={totalDeliveries.toLocaleString()}
          change={15}
          icon={<Truck size={20} />}
          color="blue"
          subtitle="Last 30 days"
        />
        <StatCard
          title="On-Time Rate"
          value={`${avgOnTime}%`}
          change={3}
          icon={<Target size={20} />}
          color="green"
          subtitle="Average across fleet"
        />
        <StatCard
          title="Avg. Rating"
          value={avgRating}
          change={2}
          icon={<Star size={20} />}
          color="yellow"
          subtitle="Customer feedback"
        />
        <StatCard
          title="Total Revenue"
          value={`$${(totalRevenue / 1000).toFixed(0)}k`}
          change={12}
          icon={<DollarSign size={20} />}
          color="purple"
          subtitle="6-month period"
        />
      </div>

      {/* Charts Row 1 */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Revenue vs Expenses */}
        <div className="bg-slate-900/60 border border-slate-800 rounded-2xl p-5">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-sm font-semibold text-white">Revenue vs Expenses</h3>
              <p className="text-xs text-slate-500">Monthly breakdown</p>
            </div>
            <DollarSign size={16} className="text-slate-500" />
          </div>
          <ResponsiveContainer width="100%" height={240}>
            <AreaChart data={analyticsData.monthlyRevenue}>
              <defs>
                <linearGradient id="revGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.2} />
                  <stop offset="95%" stopColor="#3b82f6" stopOpacity={0} />
                </linearGradient>
                <linearGradient id="expGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#ef4444" stopOpacity={0.15} />
                  <stop offset="95%" stopColor="#ef4444" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
              <XAxis dataKey="month" tick={{ fill: '#64748b', fontSize: 12 }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fill: '#64748b', fontSize: 12 }} axisLine={false} tickLine={false} tickFormatter={v => `$${v / 1000}k`} />
              <Tooltip content={<CustomTooltip />} />
              <Area type="monotone" dataKey="revenue" name="Revenue" stroke="#3b82f6" fill="url(#revGrad)" strokeWidth={2} />
              <Area type="monotone" dataKey="expenses" name="Expenses" stroke="#ef4444" fill="url(#expGrad)" strokeWidth={2} />
            </AreaChart>
          </ResponsiveContainer>
        </div>

        {/* Fuel Consumption */}
        <div className="bg-slate-900/60 border border-slate-800 rounded-2xl p-5">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-sm font-semibold text-white">Fuel Consumption</h3>
              <p className="text-xs text-slate-500">Weekly usage & cost</p>
            </div>
          </div>
          <ResponsiveContainer width="100%" height={240}>
            <BarChart data={analyticsData.fuelConsumption}>
              <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
              <XAxis dataKey="date" tick={{ fill: '#64748b', fontSize: 12 }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fill: '#64748b', fontSize: 12 }} axisLine={false} tickLine={false} />
              <Tooltip content={<CustomTooltip />} />
              <Bar dataKey="liters" name="Liters" fill="#f59e0b" radius={[6, 6, 0, 0]} />
              <Bar dataKey="cost" name="Cost ($)" fill="#8b5cf6" radius={[6, 6, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Charts Row 2 */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Weekly Deliveries */}
        <div className="bg-slate-900/60 border border-slate-800 rounded-2xl p-5">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-sm font-semibold text-white">Weekly Delivery Trend</h3>
              <p className="text-xs text-slate-500">Total vs on-time deliveries</p>
            </div>
          </div>
          <ResponsiveContainer width="100%" height={240}>
            <LineChart data={analyticsData.deliveriesPerDay}>
              <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
              <XAxis dataKey="date" tick={{ fill: '#64748b', fontSize: 12 }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fill: '#64748b', fontSize: 12 }} axisLine={false} tickLine={false} />
              <Tooltip content={<CustomTooltip />} />
              <Line type="monotone" dataKey="count" name="Total" stroke="#3b82f6" strokeWidth={2.5} dot={{ fill: '#3b82f6', r: 4 }} />
              <Line type="monotone" dataKey="onTime" name="On-Time" stroke="#22c55e" strokeWidth={2.5} dot={{ fill: '#22c55e', r: 4 }} />
            </LineChart>
          </ResponsiveContainer>
        </div>

        {/* Driver Performance Radar */}
        <div className="bg-slate-900/60 border border-slate-800 rounded-2xl p-5">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-sm font-semibold text-white">Driver Performance</h3>
              <p className="text-xs text-slate-500">Rating & on-time comparison</p>
            </div>
          </div>
          <ResponsiveContainer width="100%" height={240}>
            <RadarChart data={ratingData}>
              <PolarGrid stroke="#1e293b" />
              <PolarAngleAxis dataKey="name" tick={{ fill: '#64748b', fontSize: 11 }} />
              <PolarRadiusAxis tick={{ fill: '#475569', fontSize: 10 }} domain={[0, 100]} />
              <Radar name="On-Time %" dataKey="onTime" stroke="#3b82f6" fill="#3b82f6" fillOpacity={0.2} strokeWidth={2} />
              <Radar name="Rating" dataKey="rating" stroke="#22c55e" fill="#22c55e" fillOpacity={0.1} strokeWidth={2} />
              <Tooltip content={<CustomTooltip />} />
            </RadarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Driver Leaderboard */}
      <div className="bg-slate-900/60 border border-slate-800 rounded-2xl p-5">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <Award size={18} className="text-amber-400" />
            <h3 className="text-sm font-semibold text-white">Driver Leaderboard</h3>
          </div>
          <span className="text-xs text-slate-500">Last 30 days</span>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-slate-800">
                <th className="text-left text-xs font-medium text-slate-500 pb-3 pr-4">#</th>
                <th className="text-left text-xs font-medium text-slate-500 pb-3">Driver</th>
                <th className="text-left text-xs font-medium text-slate-500 pb-3 hidden md:table-cell">Deliveries</th>
                <th className="text-left text-xs font-medium text-slate-500 pb-3">Rating</th>
                <th className="text-left text-xs font-medium text-slate-500 pb-3">On-Time</th>
                <th className="text-left text-xs font-medium text-slate-500 pb-3 hidden md:table-cell">Performance</th>
              </tr>
            </thead>
            <tbody>
              {analyticsData.performanceByDriver
                .sort((a, b) => b.onTimeRate - a.onTimeRate)
                .map((driver, idx) => (
                  <tr key={driver.driver} className="border-b border-slate-800/50 hover:bg-slate-800/20 transition-all">
                    <td className="py-3 pr-4">
                      <span className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold ${
                        idx === 0 ? 'bg-amber-500/20 text-amber-400' :
                        idx === 1 ? 'bg-slate-400/20 text-slate-300' :
                        idx === 2 ? 'bg-orange-500/20 text-orange-400' :
                        'text-slate-500'
                      }`}>
                        {idx + 1}
                      </span>
                    </td>
                    <td className="py-3">
                      <div className="flex items-center gap-2">
                        <div className="w-8 h-8 rounded-full bg-slate-800 border border-slate-700 flex items-center justify-center text-xs font-bold text-white">
                          {driver.driver.split(' ').map(n => n[0]).join('')}
                        </div>
                        <span className="text-sm font-medium text-white">{driver.driver}</span>
                      </div>
                    </td>
                    <td className="py-3 hidden md:table-cell">
                      <span className="text-sm text-slate-300">{driver.deliveries}</span>
                    </td>
                    <td className="py-3">
                      <div className="flex items-center gap-1">
                        <Star size={12} className="text-amber-400 fill-amber-400" />
                        <span className="text-sm text-white font-medium">{driver.rating}</span>
                      </div>
                    </td>
                    <td className="py-3">
                      <span className={`text-sm font-medium ${
                        driver.onTimeRate >= 95 ? 'text-emerald-400' :
                        driver.onTimeRate >= 90 ? 'text-blue-400' :
                        driver.onTimeRate >= 85 ? 'text-amber-400' :
                        'text-red-400'
                      }`}>
                        {driver.onTimeRate}%
                      </span>
                    </td>
                    <td className="py-3 hidden md:table-cell">
                      <div className="w-24 h-2 bg-slate-800 rounded-full overflow-hidden">
                        <div
                          className={`h-full rounded-full ${
                            driver.onTimeRate >= 95 ? 'bg-emerald-500' :
                            driver.onTimeRate >= 90 ? 'bg-blue-500' :
                            driver.onTimeRate >= 85 ? 'bg-amber-500' :
                            'bg-red-500'
                          }`}
                          style={{ width: `${driver.onTimeRate}%` }}
                        />
                      </div>
                    </td>
                  </tr>
                ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Profit Summary */}
      <div className="bg-gradient-to-r from-emerald-600/10 to-blue-600/10 border border-emerald-500/20 rounded-2xl p-6">
        <div className="flex items-center gap-3 mb-4">
          <div className="p-3 rounded-xl bg-emerald-500/10">
            <TrendingUp size={24} className="text-emerald-400" />
          </div>
          <div>
            <h3 className="text-lg font-bold text-white">Monthly Profit Trend</h3>
            <p className="text-sm text-slate-400">Growing steadily over 6 months</p>
          </div>
        </div>
        <ResponsiveContainer width="100%" height={200}>
          <AreaChart data={analyticsData.monthlyRevenue}>
            <defs>
              <linearGradient id="profitGrad" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="#22c55e" stopOpacity={0.3} />
                <stop offset="95%" stopColor="#22c55e" stopOpacity={0} />
              </linearGradient>
            </defs>
            <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
            <XAxis dataKey="month" tick={{ fill: '#64748b', fontSize: 12 }} axisLine={false} tickLine={false} />
            <YAxis tick={{ fill: '#64748b', fontSize: 12 }} axisLine={false} tickLine={false} tickFormatter={v => `$${v / 1000}k`} />
            <Tooltip content={<CustomTooltip />} />
            <Area type="monotone" dataKey="profit" name="Profit" stroke="#22c55e" fill="url(#profitGrad)" strokeWidth={2.5} />
          </AreaChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}
