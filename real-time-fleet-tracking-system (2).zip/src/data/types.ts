export interface Vehicle {
  id: string;
  name: string;
  driver: string;
  driverAvatar: string;
  type: 'truck' | 'van' | 'bike';
  status: 'active' | 'idle' | 'maintenance' | 'offline';
  lat: number;
  lng: number;
  speed: number;
  heading: number;
  fuel: number;
  mileage: number;
  lastUpdate: string;
  currentRoute?: string;
  eta?: string;
  deliveriesCompleted: number;
  deliveriesTotal: number;
  phone: string;
}

export interface Shipment {
  id: string;
  trackingId: string;
  sender: string;
  recipient: string;
  origin: string;
  destination: string;
  status: 'pending' | 'picked_up' | 'in_transit' | 'out_for_delivery' | 'delivered' | 'delayed';
  vehicleId: string | null;
  weight: number;
  priority: 'low' | 'medium' | 'high' | 'urgent';
  estimatedDelivery: string;
  actualDelivery?: string;
  createdAt: string;
  updates: ShipmentUpdate[];
}

export interface ShipmentUpdate {
  timestamp: string;
  status: string;
  location: string;
  note?: string;
}

export interface RoutePoint {
  lat: number;
  lng: number;
}

export interface Route {
  id: string;
  name: string;
  vehicleId: string;
  points: RoutePoint[];
  stops: RouteStop[];
  distance: number;
  estimatedTime: number;
  status: 'planned' | 'active' | 'completed';
}

export interface RouteStop {
  id: string;
  name: string;
  address: string;
  lat: number;
  lng: number;
  type: 'pickup' | 'delivery';
  status: 'pending' | 'completed' | 'skipped';
  scheduledTime: string;
  actualTime?: string;
  shipmentId: string;
}

export interface AnalyticsData {
  deliveriesPerDay: { date: string; count: number; onTime: number }[];
  fleetUtilization: { name: string; value: number }[];
  fuelConsumption: { date: string; liters: number; cost: number }[];
  performanceByDriver: { driver: string; deliveries: number; rating: number; onTimeRate: number }[];
  deliveryHeatmap: { hour: number; day: string; count: number }[];
  monthlyRevenue: { month: string; revenue: number; expenses: number; profit: number }[];
}

export type TabType = 'dashboard' | 'map' | 'fleet' | 'shipments' | 'routes' | 'analytics';
