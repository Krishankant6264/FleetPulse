import { Vehicle, Shipment, Route, AnalyticsData } from './types';

export const vehicles: Vehicle[] = [
  {
    id: 'v1',
    name: 'Truck Alpha-01',
    driver: 'Marcus Johnson',
    driverAvatar: 'MJ',
    type: 'truck',
    status: 'active',
    lat: 40.7580,
    lng: -73.9855,
    speed: 42,
    heading: 135,
    fuel: 72,
    mileage: 45230,
    lastUpdate: '2 min ago',
    currentRoute: 'r1',
    eta: '14:35',
    deliveriesCompleted: 8,
    deliveriesTotal: 12,
    phone: '+1 (555) 234-5678'
  },
  {
    id: 'v2',
    name: 'Van Bravo-03',
    driver: 'Sarah Chen',
    driverAvatar: 'SC',
    type: 'van',
    status: 'active',
    lat: 40.7484,
    lng: -73.9967,
    speed: 28,
    heading: 45,
    fuel: 55,
    mileage: 32100,
    lastUpdate: '1 min ago',
    currentRoute: 'r2',
    eta: '15:10',
    deliveriesCompleted: 5,
    deliveriesTotal: 9,
    phone: '+1 (555) 345-6789'
  },
  {
    id: 'v3',
    name: 'Truck Charlie-07',
    driver: 'David Martinez',
    driverAvatar: 'DM',
    type: 'truck',
    status: 'idle',
    lat: 40.7614,
    lng: -73.9776,
    speed: 0,
    heading: 0,
    fuel: 88,
    mileage: 67890,
    lastUpdate: '5 min ago',
    deliveriesCompleted: 12,
    deliveriesTotal: 12,
    phone: '+1 (555) 456-7890'
  },
  {
    id: 'v4',
    name: 'Bike Delta-12',
    driver: 'Emily Park',
    driverAvatar: 'EP',
    type: 'bike',
    status: 'active',
    lat: 40.7527,
    lng: -73.9772,
    speed: 18,
    heading: 270,
    fuel: 100,
    mileage: 8450,
    lastUpdate: 'Just now',
    currentRoute: 'r3',
    eta: '13:50',
    deliveriesCompleted: 15,
    deliveriesTotal: 20,
    phone: '+1 (555) 567-8901'
  },
  {
    id: 'v5',
    name: 'Van Echo-05',
    driver: 'James Wilson',
    driverAvatar: 'JW',
    type: 'van',
    status: 'maintenance',
    lat: 40.7450,
    lng: -73.9900,
    speed: 0,
    heading: 0,
    fuel: 40,
    mileage: 55600,
    lastUpdate: '1 hour ago',
    deliveriesCompleted: 0,
    deliveriesTotal: 0,
    phone: '+1 (555) 678-9012'
  },
  {
    id: 'v6',
    name: 'Truck Foxtrot-02',
    driver: 'Lisa Anderson',
    driverAvatar: 'LA',
    type: 'truck',
    status: 'active',
    lat: 40.7690,
    lng: -73.9640,
    speed: 35,
    heading: 180,
    fuel: 63,
    mileage: 78200,
    lastUpdate: '3 min ago',
    currentRoute: 'r4',
    eta: '16:20',
    deliveriesCompleted: 3,
    deliveriesTotal: 8,
    phone: '+1 (555) 789-0123'
  },
  {
    id: 'v7',
    name: 'Bike Golf-08',
    driver: 'Alex Turner',
    driverAvatar: 'AT',
    type: 'bike',
    status: 'active',
    lat: 40.7420,
    lng: -73.9880,
    speed: 22,
    heading: 90,
    fuel: 100,
    mileage: 12300,
    lastUpdate: 'Just now',
    currentRoute: 'r5',
    eta: '14:00',
    deliveriesCompleted: 18,
    deliveriesTotal: 22,
    phone: '+1 (555) 890-1234'
  },
  {
    id: 'v8',
    name: 'Van Hotel-11',
    driver: 'Rachel Kim',
    driverAvatar: 'RK',
    type: 'van',
    status: 'offline',
    lat: 40.7380,
    lng: -73.9950,
    speed: 0,
    heading: 0,
    fuel: 15,
    mileage: 41800,
    lastUpdate: '3 hours ago',
    deliveriesCompleted: 0,
    deliveriesTotal: 0,
    phone: '+1 (555) 901-2345'
  }
];

export const shipments: Shipment[] = [
  {
    id: 's1',
    trackingId: 'FP-2024-001847',
    sender: 'TechCorp Industries',
    recipient: 'Manhattan Office Hub',
    origin: '123 Warehouse Ave, Brooklyn, NY',
    destination: '456 Park Ave, Manhattan, NY',
    status: 'in_transit',
    vehicleId: 'v1',
    weight: 45.5,
    priority: 'high',
    estimatedDelivery: '2024-01-15 14:30',
    createdAt: '2024-01-15 08:00',
    updates: [
      { timestamp: '08:00', status: 'Order Created', location: 'System' },
      { timestamp: '08:45', status: 'Picked Up', location: 'Brooklyn Warehouse' },
      { timestamp: '09:15', status: 'In Transit', location: 'Brooklyn Bridge' },
      { timestamp: '10:30', status: 'In Transit', location: 'Lower Manhattan' }
    ]
  },
  {
    id: 's2',
    trackingId: 'FP-2024-001848',
    sender: 'FreshGoods LLC',
    recipient: 'Central Market Store',
    origin: '789 Farm Rd, Queens, NY',
    destination: '321 Market St, Manhattan, NY',
    status: 'out_for_delivery',
    vehicleId: 'v2',
    weight: 120.0,
    priority: 'urgent',
    estimatedDelivery: '2024-01-15 12:00',
    createdAt: '2024-01-15 06:00',
    updates: [
      { timestamp: '06:00', status: 'Order Created', location: 'System' },
      { timestamp: '06:30', status: 'Picked Up', location: 'Queens Farm' },
      { timestamp: '07:00', status: 'In Transit', location: 'Queens Blvd' },
      { timestamp: '08:30', status: 'In Transit', location: 'Midtown Tunnel' },
      { timestamp: '09:45', status: 'Out for Delivery', location: 'Manhattan' }
    ]
  },
  {
    id: 's3',
    trackingId: 'FP-2024-001849',
    sender: 'ElectroMart',
    recipient: 'Jennifer Adams',
    origin: '555 Distribution Center, NJ',
    destination: '890 5th Ave, Manhattan, NY',
    status: 'delivered',
    vehicleId: 'v3',
    weight: 8.2,
    priority: 'medium',
    estimatedDelivery: '2024-01-15 11:00',
    actualDelivery: '2024-01-15 10:45',
    createdAt: '2024-01-14 22:00',
    updates: [
      { timestamp: '22:00', status: 'Order Created', location: 'System' },
      { timestamp: '06:00', status: 'Picked Up', location: 'NJ Distribution' },
      { timestamp: '07:30', status: 'In Transit', location: 'Lincoln Tunnel' },
      { timestamp: '09:00', status: 'Out for Delivery', location: 'Manhattan' },
      { timestamp: '10:45', status: 'Delivered', location: '890 5th Ave', note: 'Signed by J. Adams' }
    ]
  },
  {
    id: 's4',
    trackingId: 'FP-2024-001850',
    sender: 'BookWorld Online',
    recipient: 'Columbia University',
    origin: '100 Print Ave, Bronx, NY',
    destination: '2960 Broadway, Manhattan, NY',
    status: 'picked_up',
    vehicleId: 'v6',
    weight: 250.0,
    priority: 'low',
    estimatedDelivery: '2024-01-15 17:00',
    createdAt: '2024-01-15 09:00',
    updates: [
      { timestamp: '09:00', status: 'Order Created', location: 'System' },
      { timestamp: '10:00', status: 'Picked Up', location: 'Bronx Print Center' }
    ]
  },
  {
    id: 's5',
    trackingId: 'FP-2024-001851',
    sender: 'MedSupply Co',
    recipient: 'Downtown Clinic',
    origin: '400 Health Blvd, Staten Island, NY',
    destination: '75 Wall St, Manhattan, NY',
    status: 'delayed',
    vehicleId: 'v1',
    weight: 15.0,
    priority: 'urgent',
    estimatedDelivery: '2024-01-15 13:00',
    createdAt: '2024-01-15 07:00',
    updates: [
      { timestamp: '07:00', status: 'Order Created', location: 'System' },
      { timestamp: '07:30', status: 'Picked Up', location: 'Staten Island' },
      { timestamp: '08:00', status: 'In Transit', location: 'Verrazzano Bridge' },
      { timestamp: '09:30', status: 'Delayed', location: 'Brooklyn', note: 'Traffic congestion on BQE' }
    ]
  },
  {
    id: 's6',
    trackingId: 'FP-2024-001852',
    sender: 'Fashion Forward Inc',
    recipient: 'SoHo Boutique',
    origin: '200 Garment District, Manhattan, NY',
    destination: '150 Spring St, Manhattan, NY',
    status: 'in_transit',
    vehicleId: 'v4',
    weight: 5.0,
    priority: 'medium',
    estimatedDelivery: '2024-01-15 14:00',
    createdAt: '2024-01-15 11:00',
    updates: [
      { timestamp: '11:00', status: 'Order Created', location: 'System' },
      { timestamp: '11:30', status: 'Picked Up', location: 'Garment District' },
      { timestamp: '12:00', status: 'In Transit', location: 'Chelsea' }
    ]
  },
  {
    id: 's7',
    trackingId: 'FP-2024-001853',
    sender: 'Office Depot',
    recipient: 'WeWork Times Sq',
    origin: '300 Supply Way, Long Island City, NY',
    destination: '1460 Broadway, Manhattan, NY',
    status: 'pending',
    vehicleId: null,
    weight: 35.0,
    priority: 'low',
    estimatedDelivery: '2024-01-16 10:00',
    createdAt: '2024-01-15 14:00',
    updates: [
      { timestamp: '14:00', status: 'Order Created', location: 'System' }
    ]
  },
  {
    id: 's8',
    trackingId: 'FP-2024-001854',
    sender: 'Gourmet Foods Ltd',
    recipient: 'The Plaza Hotel',
    origin: '50 Food Terminal, Hunts Point, NY',
    destination: '768 5th Ave, Manhattan, NY',
    status: 'in_transit',
    vehicleId: 'v7',
    weight: 65.0,
    priority: 'high',
    estimatedDelivery: '2024-01-15 15:00',
    createdAt: '2024-01-15 10:00',
    updates: [
      { timestamp: '10:00', status: 'Order Created', location: 'System' },
      { timestamp: '10:30', status: 'Picked Up', location: 'Hunts Point Market' },
      { timestamp: '11:15', status: 'In Transit', location: 'Harlem River' }
    ]
  }
];

export const routes: Route[] = [
  {
    id: 'r1',
    name: 'Downtown Express Route',
    vehicleId: 'v1',
    distance: 18.5,
    estimatedTime: 95,
    status: 'active',
    points: [
      { lat: 40.6892, lng: -74.0445 },
      { lat: 40.7061, lng: -74.0087 },
      { lat: 40.7128, lng: -74.0060 },
      { lat: 40.7282, lng: -73.9942 },
      { lat: 40.7484, lng: -73.9856 },
      { lat: 40.7580, lng: -73.9855 },
      { lat: 40.7614, lng: -73.9776 }
    ],
    stops: [
      { id: 'rs1', name: 'Brooklyn Warehouse', address: '123 Warehouse Ave, Brooklyn', lat: 40.6892, lng: -74.0445, type: 'pickup', status: 'completed', scheduledTime: '08:30', actualTime: '08:35', shipmentId: 's1' },
      { id: 'rs2', name: 'City Hall Office', address: '31 Chambers St, Manhattan', lat: 40.7128, lng: -74.0060, type: 'delivery', status: 'completed', scheduledTime: '09:30', actualTime: '09:25', shipmentId: 's1' },
      { id: 'rs3', name: 'Union Square Store', address: '100 E 14th St, Manhattan', lat: 40.7355, lng: -73.9910, type: 'delivery', status: 'completed', scheduledTime: '10:30', actualTime: '10:40', shipmentId: 's1' },
      { id: 'rs4', name: 'Midtown Office', address: '456 Park Ave, Manhattan', lat: 40.7580, lng: -73.9855, type: 'delivery', status: 'pending', scheduledTime: '14:30', shipmentId: 's1' },
    ]
  },
  {
    id: 'r2',
    name: 'Queens-Manhattan Fresh',
    vehicleId: 'v2',
    distance: 14.2,
    estimatedTime: 75,
    status: 'active',
    points: [
      { lat: 40.7282, lng: -73.7949 },
      { lat: 40.7433, lng: -73.8230 },
      { lat: 40.7484, lng: -73.8784 },
      { lat: 40.7484, lng: -73.9415 },
      { lat: 40.7484, lng: -73.9967 }
    ],
    stops: [
      { id: 'rs5', name: 'Queens Farm', address: '789 Farm Rd, Queens', lat: 40.7282, lng: -73.7949, type: 'pickup', status: 'completed', scheduledTime: '06:30', actualTime: '06:25', shipmentId: 's2' },
      { id: 'rs6', name: 'Central Market', address: '321 Market St, Manhattan', lat: 40.7484, lng: -73.9967, type: 'delivery', status: 'pending', scheduledTime: '12:00', shipmentId: 's2' }
    ]
  },
  {
    id: 'r3',
    name: 'Midtown Express Bike',
    vehicleId: 'v4',
    distance: 5.8,
    estimatedTime: 35,
    status: 'active',
    points: [
      { lat: 40.7550, lng: -73.9900 },
      { lat: 40.7527, lng: -73.9880 },
      { lat: 40.7500, lng: -73.9850 },
      { lat: 40.7450, lng: -73.9800 },
      { lat: 40.7400, lng: -73.9780 },
      { lat: 40.7350, lng: -73.9750 }
    ],
    stops: [
      { id: 'rs7', name: 'Garment District Pickup', address: '200 Garment District', lat: 40.7550, lng: -73.9900, type: 'pickup', status: 'completed', scheduledTime: '11:30', actualTime: '11:28', shipmentId: 's6' },
      { id: 'rs8', name: 'SoHo Boutique', address: '150 Spring St', lat: 40.7250, lng: -73.9980, type: 'delivery', status: 'pending', scheduledTime: '14:00', shipmentId: 's6' }
    ]
  },
  {
    id: 'r4',
    name: 'Bronx-Uptown Route',
    vehicleId: 'v6',
    distance: 22.1,
    estimatedTime: 120,
    status: 'active',
    points: [
      { lat: 40.8176, lng: -73.9209 },
      { lat: 40.8050, lng: -73.9370 },
      { lat: 40.7900, lng: -73.9500 },
      { lat: 40.7800, lng: -73.9580 },
      { lat: 40.7690, lng: -73.9640 }
    ],
    stops: [
      { id: 'rs9', name: 'Bronx Print Center', address: '100 Print Ave, Bronx', lat: 40.8176, lng: -73.9209, type: 'pickup', status: 'completed', scheduledTime: '10:00', actualTime: '10:05', shipmentId: 's4' },
      { id: 'rs10', name: 'Columbia University', address: '2960 Broadway', lat: 40.8075, lng: -73.9626, type: 'delivery', status: 'pending', scheduledTime: '16:30', shipmentId: 's4' }
    ]
  },
  {
    id: 'r5',
    name: 'East Side Gourmet',
    vehicleId: 'v7',
    distance: 9.3,
    estimatedTime: 50,
    status: 'active',
    points: [
      { lat: 40.8200, lng: -73.8800 },
      { lat: 40.8000, lng: -73.9200 },
      { lat: 40.7800, lng: -73.9500 },
      { lat: 40.7600, lng: -73.9700 },
      { lat: 40.7420, lng: -73.9880 }
    ],
    stops: [
      { id: 'rs11', name: 'Hunts Point Market', address: '50 Food Terminal', lat: 40.8200, lng: -73.8800, type: 'pickup', status: 'completed', scheduledTime: '10:30', actualTime: '10:32', shipmentId: 's8' },
      { id: 'rs12', name: 'The Plaza Hotel', address: '768 5th Ave', lat: 40.7645, lng: -73.9745, type: 'delivery', status: 'pending', scheduledTime: '15:00', shipmentId: 's8' }
    ]
  }
];

export const analyticsData: AnalyticsData = {
  deliveriesPerDay: [
    { date: 'Mon', count: 42, onTime: 38 },
    { date: 'Tue', count: 55, onTime: 50 },
    { date: 'Wed', count: 48, onTime: 44 },
    { date: 'Thu', count: 62, onTime: 55 },
    { date: 'Fri', count: 71, onTime: 65 },
    { date: 'Sat', count: 35, onTime: 33 },
    { date: 'Sun', count: 18, onTime: 17 }
  ],
  fleetUtilization: [
    { name: 'Active', value: 62 },
    { name: 'Idle', value: 18 },
    { name: 'Maintenance', value: 12 },
    { name: 'Offline', value: 8 }
  ],
  fuelConsumption: [
    { date: 'Week 1', liters: 2400, cost: 3120 },
    { date: 'Week 2', liters: 2250, cost: 2925 },
    { date: 'Week 3', liters: 2680, cost: 3484 },
    { date: 'Week 4', liters: 2100, cost: 2730 }
  ],
  performanceByDriver: [
    { driver: 'Marcus Johnson', deliveries: 245, rating: 4.8, onTimeRate: 94 },
    { driver: 'Sarah Chen', deliveries: 198, rating: 4.9, onTimeRate: 97 },
    { driver: 'Emily Park', deliveries: 312, rating: 4.7, onTimeRate: 92 },
    { driver: 'David Martinez', deliveries: 267, rating: 4.6, onTimeRate: 89 },
    { driver: 'Lisa Anderson', deliveries: 189, rating: 4.8, onTimeRate: 95 },
    { driver: 'Alex Turner', deliveries: 334, rating: 4.5, onTimeRate: 88 },
    { driver: 'James Wilson', deliveries: 156, rating: 4.3, onTimeRate: 85 },
    { driver: 'Rachel Kim', deliveries: 201, rating: 4.7, onTimeRate: 93 }
  ],
  deliveryHeatmap: [],
  monthlyRevenue: [
    { month: 'Aug', revenue: 125000, expenses: 82000, profit: 43000 },
    { month: 'Sep', revenue: 138000, expenses: 89000, profit: 49000 },
    { month: 'Oct', revenue: 142000, expenses: 91000, profit: 51000 },
    { month: 'Nov', revenue: 155000, expenses: 95000, profit: 60000 },
    { month: 'Dec', revenue: 168000, expenses: 102000, profit: 66000 },
    { month: 'Jan', revenue: 148000, expenses: 88000, profit: 60000 }
  ]
};
